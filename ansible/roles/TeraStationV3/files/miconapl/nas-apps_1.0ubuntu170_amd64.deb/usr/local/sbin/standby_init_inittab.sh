#! /bin/bash

warn() {
	echo "${@}" 1>&2
}

load_lib() {
	. /usr/local/lib/libsys || :
}

main() {
	local inittab_path="${1}"

	if [ ! -e "${inittab_path}" ]; then
		warn "E: ${inittab_path} does not found."
		return 1
	fi

	if ! load_lib; then
		warn "E: failed to load sh libraries."
		return 1
	fi

	LibSys_override_inittab "${inittab_path}" || :

	return 0
}

main "${@}"
exit "${?}"
