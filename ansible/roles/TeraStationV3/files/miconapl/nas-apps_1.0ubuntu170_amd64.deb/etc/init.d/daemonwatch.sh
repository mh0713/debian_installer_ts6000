#!/bin/sh

if ! [ -x /usr/local/sbin/daemonwatch ]; then
    exit 0
fi

start()
{
	echo -n "Starting daemonwatch:"
	/usr/local/sbin/daemonwatch -a /etc/daemonwatch.list
}

stop()
{
	echo -n "Stop daemonwatch:"
	killall daemonwatch
	echo "done."
}

case "$1" in
    start)
	start
	;;
    stop)
	stop
	;;
    restart|reload)
	stop
	start
	;;
    *)
	echo "Usage: daemonwatch {start|stop|restart}"
	exit 1
esac

exit 0
