#!/bin/bash
#
# pwrmgr        Starts pwrmgr.
#

. /etc/nas_feature
. /usr/local/lib/libsys

RETVAL=0
DEFAULT_PORT=9
WOL_PORT=2304
PIDLSCHL=0x00000012

if [ -f /etc/melco/info ]; then
	. /etc/melco/info
fi

[ -f /etc/nologin ] && rm -f /etc/nologin

set_dtcp_ip() {
	if [ "${SUPPORT_DTCP_IP}" = "1" ]; then
		ENABLE_DTCP_IP=on
		PID=`GetProductID`
		if [ "${PID}" = "${PIDLSCHL}" ]; then
			ENABLE_DTCP_IP=off
		fi
	fi
}

set_options() {
	PWRMGROPTIONS="-bd -l /etc/pwrmgr/pclist"
	PWRMGR_STB_OPTIONS="-bds -l /etc/pwrmgr/pclist -r xfs,/dev/md1"
	if [ "${ENABLE_DTCP_IP}" = "on" ] ; then
		# DTCP-IP有効時はmオプションを付加して、セッションカウント数をチェックする
		PWRMGROPTIONS="-bdm -l /etc/pwrmgr/pclist -p ${DEFAULT_PORT} -p ${WOL_PORT}"
		PWRMGR_STB_OPTIONS="-bds -p ${DEFAULT_PORT} -p ${WOL_PORT} -l /etc/pwrmgr/pclist -r xfs,/dev/md1"
	fi
	if [ "${SUPPORT_WOL}" = "1" ] ; then
		IsWakeOnLanState
		enable_wol=$?
		if [ ${enable_wol} -eq 1 ] ; then
			# スイッチがmanualでポート9のWOLを有効にした場合、w オプションを付加する
			PWRMGR_STB_OPTIONS="-bdsw -p ${DEFAULT_PORT} -p ${WOL_PORT} -l /etc/pwrmgr/pclist -r xfs,/dev/md1"
			PWRMGROPTIONS="-bd -l /etc/pwrmgr/pclist -p ${DEFAULT_PORT} -p ${WOL_PORT}"
		fi
	fi
}

start() {
	if [ "${workingmode}" = "iSCSI" ] ; then
		exit 0
	fi

	CPU_STAT=`cat /proc/buffalo/cpu_status`
	if [ "$CPU_STAT" = "ups_shutdown" ]; then
		exit 0
	fi

	if [ "${pwrmgr}" = "off" ] ; then
		echo "pwrmgr is OFF"
		exit 0
	elif [ "${pwrmgr}" = "on" ] ; then
		:
	else
		echo "pwrmgr not setted. anyway execute pwrmgr"
		echo "pwrmgr=on" >> /etc/melco/info
	fi

	IsMountedPwrmgr=`mount |grep "/etc/pwrmgr"`
	if [ "${IsMountedPwrmgr}" != "" ] ; then
		umount -f /etc/pwrmgr
	fi

	IsStandbyMode
	RET=$?

	case ${RET} in
	0)
		[ "${QUIET}" != 1 ] && echo "This model doesnt supoort auto power function." > /dev/console
		return 0
		;;
	1)
		[ "${QUIET}" != "1" ] && echo -n $"Starting pwrmgr: "
		/usr/local/sbin/pwrmgr ${PWRMGR_STB_OPTIONS}
		RETVAL=$?
		;;
	esac

	echo
	[ $RETVAL -eq 0 ] && touch /var/lock/subsys/pwrmgr || \
	    RETVAL=1
	return $RETVAL
}

stop() {
	[ "${QUIET}" != "1" ] && echo -n $"Shutting down pwrmgr: "
	killall -TERM pwrmgr > /dev/null 2>&1 > /dev/null
	RETVAL=$?
	[ $RETVAL -eq 0 ] && rm -f /var/lock/subsys/pwrmgr
	[ "${QUIET}" != "1" ] && echo ""
	return $RETVAL
}

restart() {
	stop
	sleep 2
	start
}

reload() {
	echo -n $"Reloading pclist file: "
	killall -HUP pwrmgr
	RETVAL=$?
	echo
	return $RETVAL
}

set_dtcp_ip
set_options

case "$1" in
  start)
  	start
	# avoide to wakeup packet sender pc list in to active pclist 
  	restart
	;;
  stop)
  	stop
	;;
  restart)
  	restart
	;;
  reload)
  	reload
	;;
  *)
	echo $"Usage: $0 {start|stop|reload|restart}"
	exit 1
esac

exit $?

