#!/bin/sh
# processname: logchkd

. /etc/init.d/logtag

if ! [ -x /usr/local/sbin/logchkd ]; then
    exit 0
fi

case "$1" in
    start)
	echo -n "Starting logchkd:"
	/usr/local/sbin/logchkd
        logger -t ${LOGTAG} -p ${LOGFACILITY} 'Started logchkd'
	;;

    stop)
	echo -n "Stop logchkd:"
	killall logchkd
	echo "done."
	;;
    restart|reload)
	$0 stop
	$0 start
	;;
    *)
	echo "Usage: logchkd {start|stop|restart}"
	exit 1
esac

exit 0
